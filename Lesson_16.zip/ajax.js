function getUserInfoByGet(){
    var userInfo = {
        userName : document.getElementById("userNameFieldGet").value,
        userSurname : document.getElementById("userSurameFieldGet").value,
        userAge : document.getElementById("userAgeFieldGet").value,
        userAddress : document.getElementById("userAddressFieldGet").value
    };

    var ageInputGet = document.getElementById("userAgeFieldGet");
    ageInputGet.onfocus = cleanInput;

    if (userInfo.userAge > 0 && userInfo.userAge < 100){
        for (var key in userInfo) {
        userInfo[key] += '.ValidatedByGET';
        };

        var xhr = new XMLHttpRequest();
        xhr.open('GET','/userGet?userName='+userInfo.userName+'&userSurname='+userInfo.userSurname+'&userAge='+userInfo.userAge+'&userAddress='+userInfo.userAddress);

        xhr.setRequestHeader('Content-type','application/json'); 
        xhr.send();
    } else { 
        ageInputGet.value = "";
        ageInputGet.setAttribute("class", "warning");
        ageInputGet.setAttribute("placeholder", "You have entered impossible age");
    }
}

function getUserInfoByPost(){
    var userInfo = {
        userName : document.getElementById("userNameFieldPost").value,
        userSurname : document.getElementById("userSurameFieldPost").value,
        userAge : document.getElementById("userAgeFieldPost").value,
        userAddress : document.getElementById("userAddressFieldPost").value
    };

    var ageInputPost = document.getElementById("userAgeFieldPost");
    ageInputPost.onfocus = cleanInput;

    if (userInfo.userAge > 0 && userInfo.userAge < 100){
        for (var key in userInfo) {
        userInfo[key] += '.ValidatedByPOST';
        };

        var xhr = new XMLHttpRequest();
        xhr.open('POST','/userPost');

        xhr.setRequestHeader('Content-type','application/json'); 
        xhr.send(JSON.stringify(userInfo));
    } else { 
        ageInputPost.value = "";
        ageInputPost.setAttribute("class", "warning");
        ageInputPost.setAttribute("placeholder", "You have entered impossible age");
    };
};

function cleanInput(){
    this.classList.remove("warning");
    this.setAttribute("placeholder", "");
};

